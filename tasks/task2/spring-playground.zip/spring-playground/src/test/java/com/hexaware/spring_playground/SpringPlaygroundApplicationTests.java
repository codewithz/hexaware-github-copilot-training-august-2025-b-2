package com.hexaware.spring_playground;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringPlaygroundApplicationTests {

	@Test
	void contextLoads() {
	}

}
